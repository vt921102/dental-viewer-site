Dental Viewer — demo case
==========================

A synthetic case for trying Dental Viewer. The geometry is generated; it is
not a scan of a real person and contains no patient data.

Open it in Dental Viewer
  1. File > Import Zip... (Cmd-O) and choose this zip, or drag the zip onto
     the window. You can also unzip it and use File > Import Folder...
  2. Three meshes appear, color-coded: upper jaw, lower jaw, molar crown.
  3. Uncheck a mesh to hide it; double-click one to show it on its own;
     View > Show All Meshes brings everything back.
  4. Details lists each mesh's triangle count, volume and size in mm, plus the
     fields from demo_case.xml.
  5. Double-click the snapshot in the Snapshots list to open it.
  6. File > Save Screenshot... (Cmd-S) saves the current 3D view.

Support: https://vt921102.github.io/dental-viewer-site/support.html
